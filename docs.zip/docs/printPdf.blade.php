<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>{{ $document->name }}</title>
    <style>
        body {
            font-family: 'AE_AlMohanad', sans-serif;
            direction: rtl;
            text-align: right;
        }
        h3 {
            color: #333;
        }
        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }
        <?php if ($document->signature->count() == 1) { ?>
            .signature-table td {
            text-align: left;
            vertical-align: top;
            width: 50%; 
        }

            <?php }else{ ?>
        .signature-table td {
            text-align: center;
            vertical-align: top;
            width: 50%; 
        }
        <?php } ?>

        
        .signature img {
            width: 60px;
            height: 60px;
        }
        .created-info {
            margin-top: 20px;
            text-align: right;
        }
    </style>
</head>
<body>

    <div>
        {!! clean_html($document->content) !!}
    </div>
    @if ($document->signature->isNotEmpty())
        <table class="signature-table">
            <tr>
            @if ($document->signature->count() == 1)
                    <td style="text-align:left">
                                @if ($document->signature->first()->notes)
                                    <p>{{ $document->signature->first()->notes }}</p>
                                @else
                                    <h4>{{ App\Models\User::find($document->signature->first()->user_id)->name }}</h4>
                                @endif
                                <img  src="{{ $document->signature->first()->image }}" alt="Signature">

                    <td>
            @else
                @foreach ($document->signature->reverse() as $signature)
                    <td>
                        @if ($signature->notes)
                            <p>{{ $signature->notes }}</p>
                        @else
                            <h4>{{ App\Models\User::find($signature->user_id)->name }}</h4>
                        @endif
                        <img src="{{ $signature->image }}" alt="Signature">
                    </td>
                @endforeach
            @endif
            </tr>
        </table>
    @endif

</body>
</html>
